import React, { useState, useEffect } from 'react';
import { format, addDays, differenceInDays } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import { Moon, Star, Save, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import StarField from './components/StarField';
import MoonPhase from './components/MoonPhase';
import LunarCalendar from './components/LunarCalendar';
import { getMoonPhase, getMoonIllumination, getNextFullMoonDate } from './utils/moonCalculations';

function App() {
  const [note, setNote] = useState('');
  const [savedNotes, setSavedNotes] = useState<{date: string, text: string}[]>([]);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [specialMessage, setSpecialMessage] = useState<string | null>(null);
  const [showCalendar, setShowCalendar] = useState(false);
  const [currentViewDate, setCurrentViewDate] = useState(new Date());
  
  // Get current moon phase
  const today = new Date();
  const moonPhase = getMoonPhase(today);
  const illumination = getMoonIllumination(today);
  const nextFullMoon = getNextFullMoonDate(today);
  const daysUntilFullMoon = differenceInDays(nextFullMoon, today);
  
  // Check for special dates (example implementation)
  useEffect(() => {
    const dayOfMonth = today.getDate();
    const month = today.getMonth();
    
    // Full moon
    if (moonPhase === 'Full Moon') {
      setSpecialMessage('Full Moon tonight! A time for completion and clarity. ✨');
    }
    // New moon
    else if (moonPhase === 'New Moon') {
      setSpecialMessage('New Moon tonight! Set your intentions for the cycle ahead. 🌑');
    }
    // Birthday example (replace with actual logic)
    else if (dayOfMonth === 15 && month === 3) {
      setSpecialMessage('Tonight, the universe celebrates YOU. 🌙🎉');
    } else {
      setSpecialMessage(null);
    }
  }, [moonPhase, today]);

  const handleSaveNote = () => {
    if (!note.trim()) return;
    
    setSaveStatus('saving');
    
    // Simulate saving to database
    setTimeout(() => {
      try {
        const newNote = {
          date: format(today, 'yyyy-MM-dd'),
          text: note.trim()
        };
        
        setSavedNotes([...savedNotes, newNote]);
        setNote('');
        setSaveStatus('saved');
        
        // Reset status after showing success
        setTimeout(() => setSaveStatus('idle'), 2000);
      } catch (error) {
        setSaveStatus('error');
        setTimeout(() => setSaveStatus('idle'), 2000);
      }
    }, 800);
  };

  const toggleCalendar = () => {
    setShowCalendar(!showCalendar);
  };

  const goToPreviousDay = () => {
    setCurrentViewDate(prevDate => addDays(prevDate, -1));
  };

  const goToNextDay = () => {
    setCurrentViewDate(prevDate => addDays(prevDate, 1));
  };

  return (
    <div className="cosmic-container min-h-screen">
      <StarField optimized={true} />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Date Header */}
        <motion.div 
          className="mb-8 flex flex-col items-center"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          <div className="flex items-center gap-2 font-mono">
            <motion.button
              className="text-white/60 hover:text-moonglow transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={goToPreviousDay}
            >
              <ChevronLeft className="h-5 w-5" />
            </motion.button>
            
            <button 
              className="text-moonglow text-xl font-medium hover:text-white transition-colors"
              onClick={toggleCalendar}
            >
              {format(currentViewDate, 'MMM dd')}
            </button>
            
            <motion.button
              className="text-white/60 hover:text-moonglow transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={goToNextDay}
            >
              <ChevronRight className="h-5 w-5" />
            </motion.button>
          </div>
          
          <p className="text-space-100/60 text-sm mt-1 font-poppins">
            {daysUntilFullMoon === 0 
              ? "Full Moon tonight! 🌕" 
              : `Next full moon in ${daysUntilFullMoon} day${daysUntilFullMoon !== 1 ? 's' : ''} 🌕`}
          </p>
        </motion.div>

        <header className="text-center mb-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <h1 className="text-4xl font-bold text-moonglow flex items-center justify-center gap-2">
              <Moon className="h-8 w-8" />
              <span>Luna</span>
            </h1>
            <p className="text-stardust/80 font-poppins font-light mt-1">
              Moon Phase & Daily Reflection
            </p>
          </motion.div>
        </header>

        <div className="lg:flex lg:items-center lg:gap-12">
          {/* Moon Phase Section */}
          <motion.div 
            className="flex-1 flex flex-col items-center mb-12 lg:mb-0 relative"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5 }}
          >
            <motion.div
              className="relative"
              animate={{ y: [0, -10, 0] }}
              transition={{ 
                repeat: Infinity, 
                duration: 6,
                ease: "easeInOut"
              }}
            >
              <MoonPhase phase={moonPhase} size={300} optimized={true} />
              
              {/* Calendar Button */}
              <motion.button
                className="absolute top-0 right-0 p-2 glassmorphism rounded-full text-moonglow hover:text-white hover:bg-space-700/70 transition-all"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={toggleCalendar}
                aria-label="Open lunar calendar"
              >
                <Calendar className="h-5 w-5" />
              </motion.button>
            </motion.div>
            
            <motion.h2 
              className="text-3xl font-bold mt-6 text-white"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
            >
              {moonPhase}
            </motion.h2>
            
            <motion.p 
              className="text-xl text-stardust flex items-center gap-2 mt-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 1 }}
            >
              <Moon className="h-5 w-5 text-moonglow" /> 
              {Math.round(illumination * 100)}% Illuminated
            </motion.p>
            
            <motion.p 
              className="text-sm text-stardust/70 mt-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9, duration: 1 }}
            >
              {format(today, 'MMMM d, yyyy')}
            </motion.p>
            
            {specialMessage && (
              <motion.div 
                className="mt-6 glassmorphism p-4 rounded-lg border border-moonglow/30 text-moonglow"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1, duration: 0.5 }}
              >
                {specialMessage}
              </motion.div>
            )}
          </motion.div>
          
          {/* Daily Note Section */}
          <motion.div 
            className="flex-1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 1 }}
          >
            <div className="glassmorphism rounded-xl p-6">
              <h3 className="text-xl font-medium text-moonglow mb-4 flex items-center gap-2">
                <Star className="h-5 w-5" />
                Daily Reflection
              </h3>
              
              <textarea
                className="input-field h-40 resize-none font-poppins"
                placeholder="The moon remembers… write your thoughts here."
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
              
              <div className="mt-4 flex justify-end">
                <motion.button 
                  className={`btn-primary flex items-center gap-2 ${
                    saveStatus === 'saving' ? 'opacity-70' : ''
                  } ${
                    saveStatus === 'error' ? 'border-red-500 text-red-400' : ''
                  }`}
                  onClick={handleSaveNote}
                  disabled={saveStatus === 'saving' || !note.trim()}
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ 
                    backgroundColor: 'rgba(44, 25, 80, 0.7)',
                  }}
                  animate={saveStatus === 'saved' ? {
                    boxShadow: ['0 0 0 rgba(253, 230, 138, 0)', '0 0 15px rgba(253, 230, 138, 0.7)', '0 0 0 rgba(253, 230, 138, 0)'],
                  } : {}}
                  transition={saveStatus === 'saved' ? {
                    duration: 0.5,
                    ease: 'easeInOut',
                  } : {}}
                >
                  {saveStatus === 'saving' ? (
                    'Saving...'
                  ) : saveStatus === 'saved' ? (
                    <>Saved</>
                  ) : saveStatus === 'error' ? (
                    'Failed to save 🌑'
                  ) : (
                    <>
                      <Save className="h-4 w-4" />
                      Save to the Stars ✨
                    </>
                  )}
                </motion.button>
              </div>
              
              {savedNotes.length === 0 && (
                <p className="text-center text-stardust/60 mt-6 font-poppins text-sm italic">
                  No notes tonight. Let the moon inspire you…
                </p>
              )}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Calendar Button */}
      <motion.button
        className="fixed bottom-6 right-6 p-4 glassmorphism rounded-full text-moonglow shadow-lg shadow-moonglow/20 z-20"
        whileHover={{ scale: 1.1, boxShadow: '0 0 15px rgba(253, 230, 138, 0.4)' }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleCalendar}
        aria-label="Toggle lunar calendar"
      >
        <Moon className="h-6 w-6" />
      </motion.button>

      {/* Lunar Calendar Modal */}
      <AnimatePresence>
        {showCalendar && (
          <LunarCalendar 
            onClose={toggleCalendar} 
            savedNotes={savedNotes}
            specialDates={[
              { date: '2025-04-15', type: 'birthday', message: 'Your cosmic birthday! 🎂✨' }
            ]}
            currentDate={currentViewDate}
            onDateChange={setCurrentViewDate}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;